cd {{PATH TO THIS DIRECTORY}}
RFD.exe --run_client --verbose --config "GameConfig.toml" -u {{USER CODE}}

NOTE:
If you're running Lumber Tycoon at least twice in a row, add `--keep_cache`.